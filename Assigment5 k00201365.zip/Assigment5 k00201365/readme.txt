I added a feature that allows the user to know how many days until that date
I believe all the specifications for this profect have been met, apart from form validation.
I also added a feature that will print the birthday of certain well-known people. 
20/06