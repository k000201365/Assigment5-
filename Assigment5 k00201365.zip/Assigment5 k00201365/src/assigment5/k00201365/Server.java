package assigment5.k00201365;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
public class Server {
    public static void main(String[] args) {
        int Person = 1;        
        ArrayList<Integer> frequence = ReadDaysFile();        
        try {
            ServerSocket serverSocket = new ServerSocket(8000);
            System.out.println("Server running and awaiting connections");
            while (true) {
                Socket connectToClient = serverSocket.accept();             
                InetAddress clientInetAddress = connectToClient.getInetAddress();
                String ipAddress = clientInetAddress.getHostAddress();
                System.out.println("connection "+Person+" ip address is "+clientInetAddress.getHostName());                
                HandleAClient thread = new HandleAClient(connectToClient, ipAddress, frequence);
                thread.start();
                Person++;
            }
        } catch (IOException ex) {
            System.err.println(ex);
        }
    }
    
    private static ArrayList<Integer> ReadDaysFile() {
        BufferedReader in = null;
        String result;
        ArrayList<Integer> frequence = new ArrayList<>();
        try {
            in = new BufferedReader(new FileReader("days.txt"));
            in.readLine();
            while ((result = in.readLine()) != null) {
                if (!result.trim().isEmpty()) {
                    String[] splited = result.replaceAll("[a-zA-Z]", "").trim().split("\\s+");
                    for (String splited1 : splited) {
                        frequence.add(Integer.parseInt(splited1));
                    }
                }
            }
        } catch (IOException ex) {
            System.err.println(ex);
        }
        return frequence;
    }
}

class HandleAClient extends Thread {
    private final Socket connectToClient; // A connected socket
    private final String clientsIP;
    private final ArrayList<Integer> values;
    private BufferedReader input;
    
    public HandleAClient(Socket socket, String IP, ArrayList frequence) throws IOException {
        connectToClient = socket;
        clientsIP = IP;
        values = frequence;
    }
    
    public void run() {
        try {
            DataInputStream isFromClient = new DataInputStream(connectToClient.getInputStream());
            DataOutputStream osToClient = new DataOutputStream(connectToClient.getOutputStream());
            input = new BufferedReader(new InputStreamReader(connectToClient.getInputStream()));  
            while(true) {          
                String fromServer = isFromClient.readUTF().trim();
                int indexValue = ConvertDateToDayInYear(fromServer);
                osToClient.writeInt(values.get(indexValue - 1));
            }
        } catch (IOException ex) {            
            System.err.println(ex);
        }
    }
    
    private int ConvertDateToDayInYear(String dateStr) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String localDate = dateStr + "/2020";
        LocalDate date = LocalDate.parse(localDate, formatter);
        int dayOfYear = date.getDayOfYear();
        return dayOfYear;
    }
}
