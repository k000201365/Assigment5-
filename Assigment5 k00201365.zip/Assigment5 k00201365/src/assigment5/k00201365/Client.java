package assigment5.k00201365;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Calendar;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
public class Client {
  public static void main(String[] args) {
        try {
            DataInputStream Fserver;
            DataOutputStream Tserver;
            try (Scanner scanner = new Scanner(System.in)) {
                Socket connectToServer = new Socket("localhost", 8000);
                Fserver = new DataInputStream(
                connectToServer.getInputStream());
                Tserver = new DataOutputStream(connectToServer.getOutputStream());
                while (true) {
                    System.out.println("Please enter the date in a (00/00)format:");
                    String tosend = scanner.nextLine();
                    Tserver.writeUTF(tosend);
                    String dates[]=tosend.split("/");
                    int Theday =Integer.parseInt(dates[0]);
                    int Themouth =Integer.parseInt(dates[1]);
                    int rightmouth, Today, day , amouth;
                    Calendar cal = Calendar.getInstance();
                    int Thedays = cal.get(Calendar.DAY_OF_MONTH);
                    int Get = Fserver.readInt();
                    Today=Thedays;
                    int mouth  = cal.get(Calendar.MONTH);
                    rightmouth = mouth +1;
                    amouth =Themouth;
                    day =Theday;
                    int currentDateCount = Today;
                    int Counter = day ;
                    if(tosend.equals("quit"))
                    {
                        System.out.println("The connection is down : " + scanner);
                        scanner.close();
                        System.out.println("Connection down");
                        break;
                    }
                    switch (Get % 10) {
                        case 1:
                            System.out.println(Theday + "/" +Themouth +" is the " + Get + "st most popular birthday");
                            break;
                        case 2:
                            System.out.println(Theday+ "/" + Themouth +" is the " + Get + "nd most popular birthday");
                            break;
                        case 3:
                            System.out.println(Theday + "/" + Themouth +" is the " + Get + "rd most popular birthday");
                            break;
                        case 6:
                            System.out.println(Theday + "/" + Themouth +" is the " + Get + "st most popular birthday");
                            break;
                        default:
                            System.out.println(Theday + "/" + Themouth +" is the " + Get + "th most popular birthday");
                            break;
                    }
                    if ( Themouth == 4 && Theday == 20 )
                    {
                        System.out.println("Today is Hitler Birthday");
                  
                    }
                     else if ( Themouth == 3 && Theday == 14 )
                    {
                        System.out.println("Today is Enstines Birthday");
                    
                    }
                       else if ( Themouth == 25 && Theday == 12 )
                    {
                        System.out.println("Jesus was born today");
                     
                    }
                        else  if ( Themouth == 7 && Theday == 10 )
                    {
                      System.out.println("Nikola Tesla was born today");
                    }
                         else   if ( Themouth == 6 && Theday == 20 )
                    {
                      System.out.println("Queen Victoria was born today");
                    }
                         else if ( Themouth == 6 && Theday == 28 )
                    {
                        System.out.println("Elon musks Birthday today,");
                    }
                    else
                    {
                        for (int i = 1; i < rightmouth; i++)
                        {
                            switch (i) {
                                case 1:
                                case 3:
                                case 5:
                                case 7:
                                case 8:
                                case 10:
                                case 12:
                                    currentDateCount = currentDateCount + 31;
                                    break;
                                case 2:
                                    currentDateCount = currentDateCount + 28;
                                    break;
                                case 4:
                                case 6:
                                case 9:
                                case 11:
                                    currentDateCount = currentDateCount + 30;
                                    break;
                                default:
                                    break;
                            }
                        }
                        for (int i = 1; i < amouth; i++)
                        {
                            switch (i) {
                                case 1:
                                case 3:
                                case 5:
                                case 7:
                                case 8:
                                case 10:
                                case 12:
                                    Counter = Counter + 31;
                                    break;
                                case 2:
                                    Counter = Counter + 28;
                                    break;
                                case 4:
                                case 6:
                                case 9:
                                case 11:
                                    Counter = Counter + 30;
                                    break;
                                default:
                                    break;
                            }
                        }
                        int Lastyear, Thisyear;
                        if (currentDateCount > Counter)
                        {
                            Lastyear = currentDateCount - Counter;
                            Thisyear = 365 - Lastyear;
                        }
                        else
                        {
                            Thisyear = Counter - currentDateCount;                      
                        }                   
                        System.out.println(Thisyear +
                                " more days till this date.");
                    }
                }
            }
         Tserver.close();
         Fserver.close();      
        
  }   catch (IOException ex) {
          Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
      }
  }
}
  